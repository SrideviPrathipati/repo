package com.example.demo.service.impl;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.exception.DepartmentNotFoundException;
import com.example.demo.exception.EntityAlreadyExistsException;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    DepartmentRepository departmentRepository;

    //create department
    public void createDepartment(Department department){
        Optional<Department> department1 = departmentRepository.getById(department.getId());
        if(department1.isPresent()){
            throw new EntityAlreadyExistsException("Department with this id already exist");
        }
        else {
            departmentRepository.save(department);
        }
    }

    //delete department
    public void deleteDepartment(Long deptId){
        departmentRepository.deleteById(deptId);
    }

    //getdeptDetails
    @Override
    public DepartmentDto getDepartmentDetails(Long deptId) {
        Optional<Department> department = departmentRepository.getById(deptId);
        if(department.isPresent()) {
            return toDto(department.get());
        }
        else {
            throw new DepartmentNotFoundException("Department id not found");
        }
    }

    //get all dept details
    @Override
    public List<DepartmentDto> getAllDepartments() {
        return toDtoList(departmentRepository.findAll());
    }

    //update existing department
    @Override
    public void updateDepartment(Department department) {
        Optional<Department> dept = departmentRepository.getById(department.getId());
        if(!dept.isPresent()) {
            throw new DepartmentNotFoundException("Department id not found");
        }
       departmentRepository.save(department);
    }

    //to return convert entity to dto
    private DepartmentDto toDto(Department department){
        return DepartmentDto.builder()
                .deptId(department.getId()).deptName(department.getDeptName()).build();
    }
    //to return convert entity list to dto list
    private List<DepartmentDto> toDtoList(List<Department> departments) {
        List<DepartmentDto> departmentDtos = new ArrayList<>();
        for (Department d : departments) {
            DepartmentDto departmentDto = DepartmentDto.builder()
                    .deptId(d.getId()).deptName(d.getDeptName()).build();
            departmentDtos.add(departmentDto);
        }
        return departmentDtos;
    }

}
