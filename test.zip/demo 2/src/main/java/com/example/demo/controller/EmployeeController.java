package com.example.demo.controller;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping(value = "/create_employee" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createEmployee(@Valid @RequestBody EmployeeDto employeeDto) throws NotFoundException {
        employeeService.createEmployee(employeeDto);
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @GetMapping(value ="/get/employee_details", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Employee> getEmployeeDetailsById(@RequestParam Long empId){
       return ResponseEntity.ok(employeeService.getEmpDetails(empId));
    }

    @GetMapping(value ="/get/all_employees", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Employee>> getAllEmployeeDetails(){
        return ResponseEntity.ok(employeeService.getAllEmpDetails());
    }

    @PutMapping(value = "/update_employee" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updateEmployee(@RequestBody Employee employee){
        employeeService.updateEmployee(employee);
        return new ResponseEntity(HttpStatus.OK);
    }


    @DeleteMapping(value = "/delete_employee", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity deleteEmployee(@RequestParam Long empId){
        employeeService.deleteEmployee(empId);
        return new ResponseEntity(HttpStatus.ACCEPTED);
    }

}
