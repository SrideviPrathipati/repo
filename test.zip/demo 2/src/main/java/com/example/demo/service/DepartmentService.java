package com.example.demo.service;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;

import java.util.List;

public interface DepartmentService {

    public void createDepartment(Department department);

    public void deleteDepartment(Long deptId);

    public DepartmentDto getDepartmentDetails(Long deptId);

    public List<DepartmentDto> getAllDepartments();

    public void updateDepartment(Department department);
}
