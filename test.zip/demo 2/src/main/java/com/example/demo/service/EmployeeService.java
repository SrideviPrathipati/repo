package com.example.demo.service;

import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import javassist.NotFoundException;

import java.util.List;

public interface EmployeeService {

    public void createEmployee(EmployeeDto employeeDto) throws NotFoundException;

    public Employee getEmpDetails(Long empId);

    public List<Employee> getAllEmpDetails();

    public void updateEmployee(Employee employee);

    public void deleteEmployee(Long empId);



}
