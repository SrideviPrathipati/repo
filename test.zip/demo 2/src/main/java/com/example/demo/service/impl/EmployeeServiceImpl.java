package com.example.demo.service.impl;

import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.exception.DepartmentNotFoundException;
import com.example.demo.exception.EntityAlreadyExistsException;
import com.example.demo.exception.InvalidRequestException;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    //create a new employee record
    @Override
    public void createEmployee(EmployeeDto employeeDto) throws NotFoundException {
        Optional<Employee> employee = employeeRepository.getById(employeeDto.getEmployeeId());
        if(employee.isPresent()){
            throw new EntityAlreadyExistsException("Record exist with this id");
        }

        Optional<Department> department = departmentRepository.getById(employeeDto.getDeptId());
        if(department.isPresent()) {
            Employee emp = Employee.builder().id(employeeDto.getEmployeeId()).
                    empName(employeeDto.getEmpName()).department(department.get()).build();
            employeeRepository.save(emp);
        }
        else
            throw new DepartmentNotFoundException("Department id not found");
    }

    //get emp details by empId
    @Override
    public Employee getEmpDetails(Long empId) {
       return employeeRepository.getById(empId).get();
    }

    //get all employees
    @Override
    public List<Employee> getAllEmpDetails(){
        return employeeRepository.findAll();
    }

    //update employee details
    @Override
    public void updateEmployee(Employee employee) {
        Optional<Employee> emp = employeeRepository.getById(employee.getId());
        if(!emp.isPresent()) {
            throw new InvalidRequestException("Record does not exist with dept id given");
        }
        employeeRepository.save(employee);
    }

    //delete employee record
    @Override
    public void deleteEmployee(Long empId) {
       Optional<Employee> employee = employeeRepository.getById(empId);
       if(!employee.isPresent()){
           throw new InvalidRequestException("Emp Record does not exist with emp id given");
       }
       employeeRepository.deleteById(empId);
    }
}
