package com.example.demo.exception;

import lombok.Builder;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.CONFLICT, reason = "ID already exists")
public class EntityAlreadyExistsException extends RuntimeException {
    @Builder
    public EntityAlreadyExistsException(String message) {
        super(message);
    }
}
