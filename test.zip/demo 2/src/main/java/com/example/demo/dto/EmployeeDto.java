package com.example.demo.dto;

import lombok.*;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDto {

    @NotNull
    private Long EmployeeId;

    @NotNull
    private String empName;

    @NotNull
    private Long deptId;
}
