package com.example.demo.exception;

import lombok.Builder;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "please check the department id , given department id is not valid")
public class DepartmentNotFoundException extends RuntimeException {
    @Builder
    public DepartmentNotFoundException(String message) {
        super(message);
    }
}
