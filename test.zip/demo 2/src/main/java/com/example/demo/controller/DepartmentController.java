package com.example.demo.controller;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    DepartmentService departmentService;

    @PostMapping(value = "/create_department" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createDepartment(@Valid @RequestBody Department department){
        departmentService.createDepartment(department);
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @PutMapping(value = "/update_department" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updateDepartment(@RequestBody Department department){
        departmentService.updateDepartment(department);
        return new ResponseEntity(HttpStatus.OK);
    }

    @GetMapping(value = "/getDepartment" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DepartmentDto> getDepartmentDetails(@RequestParam Long deptId){
        return new ResponseEntity(departmentService.getDepartmentDetails(deptId), HttpStatus.OK);
    }

    @GetMapping(value = "/get/all_departments" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DepartmentDto>> getAllDepartments(){
        return  ResponseEntity.ok(departmentService.getAllDepartments());
    }

    @DeleteMapping(value = "/delete_dept", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity deleteDepartment(@RequestParam Long deptId){
        departmentService.deleteDepartment(deptId);
        return new ResponseEntity(HttpStatus.ACCEPTED);
    }

}
